/* This source file only exists to keep libtool happy. */

char jas_dummy;
